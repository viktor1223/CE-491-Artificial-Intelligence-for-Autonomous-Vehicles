function [XTrain XTest yTrain yTest] = mySplitData(X, y, rate)

% Splits the data into training and testing















end
