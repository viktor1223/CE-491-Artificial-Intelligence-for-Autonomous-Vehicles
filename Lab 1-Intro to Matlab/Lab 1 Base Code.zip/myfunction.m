function y = myfunction(x)
% Function of one argument with one return value

a = 42;              % Have a global variable of the same name

y = a + x;